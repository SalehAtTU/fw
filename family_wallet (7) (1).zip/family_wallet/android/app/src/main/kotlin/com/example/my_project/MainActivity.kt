package com.mycompany.familywallet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
